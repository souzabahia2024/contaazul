Eu removi a pasta "vendor" que vem do composer, porque são arquivos relativamente pesados que você pode instalar no seu próprio projeto, ok?

Então, lembra de, antes de rodar, instalar o composer e suas dependências... elas já estão anotadas lá no composer.json