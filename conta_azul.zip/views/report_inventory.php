<h1>Relatório de Estoque</h1>
<form method="GET" onsubmit="return openPopup(this)">
	<div style="clear:both"></div>

	<div style="text-align:center">
		<input type="submit" value="Gerar Relatório" />
	</div>
</form>
<script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/report_inventory.js"></script>