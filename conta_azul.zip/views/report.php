<h1>Relatórios</h1>

<div class="report_item">
	<a href="<?php echo BASE_URL; ?>/report/sales">
		<img src="<?php echo BASE_URL; ?>/assets/images/sales.png" border="0" height="80" />
		<br/><br/>
		Relatório de Vendas
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL; ?>/report/inventory">
		<img src="<?php echo BASE_URL; ?>/assets/images/inventory.png" border="0" height="80" />
		<br/><br/>
		Relatório de Estoque
	</a>
</div>